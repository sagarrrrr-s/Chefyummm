package com.example.foodblog

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
