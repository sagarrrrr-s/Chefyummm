import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:foodblog/screens/home/home.dart';
import 'package:foodblog/style.dart';

class App extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Home(),
      theme: ThemeData(
          textTheme: TextTheme(
              headline1: TextStyle(
                  fontSize: 25,
                  color: Color(0xFFfbb53d),
                  fontFamily: "Sans",
                  fontWeight: FontWeight.w900),
              headline2: TextStyle(fontSize: 40, color: Colors.black),
              bodyText1: TextStyle(
                  fontSize: 20, color: Colors.black, fontFamily: "Sans"),
              bodyText2: TextStyle(
                  fontSize: 25, color: Color(0xFFfbb53d), fontFamily: "Sans"),
              button: TextStyle(
                  fontSize: 20, color: Colors.black, fontFamily: "Sans"),
              subtitle1: TextStyle(
                  fontSize: 18, color: Colors.black, fontFamily: "Sans"),
              subtitle2: TextStyle(
                  fontSize: 18, color: Colors.black, fontFamily: "Sans")),
          inputDecorationTheme: InputDecorationTheme(
              contentPadding: EdgeInsets.zero,
              focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: hintColor)),
              enabledBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: hintColor),
              ),
              border: UnderlineInputBorder(
                borderSide: BorderSide(color: hintColor),
              ),
              prefixStyle: TextStyle(
                  fontSize: 18, color: Colors.black, fontFamily: "Sans"),
              labelStyle: TextStyle(
                  color: hintColor, fontSize: 18, fontFamily: "Sans")),
          buttonTheme: ButtonThemeData(
              buttonColor: Colors.red,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30)),
              padding: EdgeInsets.all(15)),
          brightness: Brightness.light,
          appBarTheme: AppBarTheme(
              color: Colors.white,
              elevation: 0,
              iconTheme: IconThemeData(color: Colors.black),
              textTheme: TextTheme(
                  title: TextStyle(
                      fontSize: 30,
                      color: Color(0xFFfbb53d),
                      fontWeight: FontWeight.bold,
                      fontFamily: "Sans")))),
    );
  }
}
