import 'package:flutter/material.dart';
import 'package:foodblog/models/blog.dart';
import 'package:foodblog/style.dart';

class BlogPage extends StatefulWidget {
  final Blog b;
  BlogPage({Key key, this.b}) : super(key: key);

  @override
  _BlogPageState createState() => _BlogPageState();
}

class _BlogPageState extends State<BlogPage> {
  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Padding(
        padding: EdgeInsets.all(20.0),
        child: ListView(
          children: [
            Text(
              widget.b.title,
              style: text.headline2,
            ),
            Text(
              "by " + widget.b.author,
              style: text.bodyText2,
            ),
            SizedBox(
              height: 20,
            ),
            Image.network(
              api + "/images/" + widget.b.img[0],
            ),
            SizedBox(
              height: 20,
            ),
            Text("Reciepe:"),
            Text(
              widget.b.desc,
              style: text.subtitle1,
            )
          ],
        ),
      ),
    );
  }
}
