class Blog {
  final String id;
  final String title;
  final String desc;
  final String author;
  final List img;

  Blog(this.id, this.title, this.desc, this.author, this.img);
  factory Blog.store(final json) {
    List img = [];
    List i = json['images'];
    i.forEach((element) {
      img.add(element['url']);
    });

    return Blog(
        json['id'], json['title'], json['description'], json['author'], img);
  }
}
