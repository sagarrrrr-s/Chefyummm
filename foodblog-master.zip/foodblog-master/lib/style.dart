import 'package:flutter/material.dart';

final api = "http://chefyumm-env.eba-sfjrfiec.ap-south-1.elasticbeanstalk.com";
Color hintColor = Color(0xFF747889);
EdgeInsets padding = EdgeInsets.symmetric(horizontal: 20);
