import 'package:flutter/material.dart';
import 'package:foodblog/app.dart';

void main() async {
  runApp(App());
}
