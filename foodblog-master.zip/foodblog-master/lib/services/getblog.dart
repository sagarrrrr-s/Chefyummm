import 'dart:convert';

import 'package:foodblog/models/blog.dart';
import 'package:foodblog/style.dart';
import 'package:http/http.dart' as http;

Future getAllBlogs() async {
  String url = api + "/blog/getAllBlogs";
  final response = await http.get(url);
  final data = json.decode(response.body);
  List movies = data["details"]["data"];
  List<Blog> pro = [];
  // print(movies[0]);
  movies.forEach((element) {
    //print(element["images"][0]["url"]);
    pro.add(Blog.store(element));
  });
  return pro;
}
